create
  definer = root@localhost function udf_count_colonists_by_destination_planet(planet_name varchar(30)) returns int
BEGIN
	DECLARE `count` INT(11);
    SET `count` := (SELECT COUNT(`tc`.`id`)
    FROM `planets` AS `p`
    JOIN `spaceports` AS `s`
    ON `p`.`id` = `s`.`planet_id`
    JOIN `journeys` AS `j`
    ON `s`.`id` = `j`.`destination_spaceport_id`
    JOIN `travel_cards` AS `tc`
    ON `j`.`id` = `tc`.`journey_id`
    WHERE `p`.`name` = `planet_name`
    GROUP BY `p`.`name`);
    RETURN `count`;
END;

