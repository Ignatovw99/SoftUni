package cresla.entities.modules;

public class CryogenRod extends BaseEnergyModule {
    public CryogenRod(int id, int energyOutput) {
        super(id, energyOutput);
    }
}
