package lordOfTheRings.models.food;

public class UnknownFood extends Food {
    public UnknownFood(int happinessPoints) {
        super(happinessPoints);
    }
}
