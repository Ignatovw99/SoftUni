package lordOfTheRings.models.food;

public class Cram extends Food {
    public Cram(int happinessPoints) {
        super(happinessPoints);
    }
}
