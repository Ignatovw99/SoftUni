package lordOfTheRings.models.food;

public class HoneyCake extends Food {
    public HoneyCake(int happinessPoints) {
        super(happinessPoints);
    }
}
