package lordOfTheRings.models.food;

public class Lembas extends Food {
    public Lembas(int happinessPoints) {
        super(happinessPoints);
    }
}
