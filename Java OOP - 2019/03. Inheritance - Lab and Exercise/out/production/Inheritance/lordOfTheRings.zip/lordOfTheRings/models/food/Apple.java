package lordOfTheRings.models.food;

public class Apple extends Food {
    public Apple(int happinessPoints) {
        super(happinessPoints);
    }
}
