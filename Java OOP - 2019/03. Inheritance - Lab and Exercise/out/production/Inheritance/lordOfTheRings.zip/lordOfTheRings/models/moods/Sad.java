package lordOfTheRings.models.moods;

public class Sad extends Mood {
}
