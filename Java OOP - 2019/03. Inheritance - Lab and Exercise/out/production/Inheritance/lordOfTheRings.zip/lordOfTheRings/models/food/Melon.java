package lordOfTheRings.models.food;

public class Melon extends Food {
    public Melon(int happinessPoints) {
        super(happinessPoints);
    }
}
