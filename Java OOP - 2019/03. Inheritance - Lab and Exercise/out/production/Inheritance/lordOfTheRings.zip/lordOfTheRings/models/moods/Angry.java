package lordOfTheRings.models.moods;

public class Angry extends Mood {
}
