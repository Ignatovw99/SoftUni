package lordOfTheRings.models.moods;

public class JavaScript extends Mood {
}
