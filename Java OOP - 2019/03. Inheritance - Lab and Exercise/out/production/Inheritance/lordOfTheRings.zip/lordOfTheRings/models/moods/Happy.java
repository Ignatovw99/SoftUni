package lordOfTheRings.models.moods;

public class Happy extends Mood {
}
