package lordOfTheRings.models.food;

public class Mushrooms extends Food {
    public Mushrooms(int happinessPoints) {
        super(happinessPoints);
    }
}
