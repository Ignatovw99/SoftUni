package interfaces;

import foodmodels.Food;

public interface Feedable {
    void eat(Food food);
}
