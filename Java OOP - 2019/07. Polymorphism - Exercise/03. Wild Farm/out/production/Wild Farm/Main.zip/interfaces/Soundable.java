package interfaces;

public interface Soundable {
    String makeSound();
}
