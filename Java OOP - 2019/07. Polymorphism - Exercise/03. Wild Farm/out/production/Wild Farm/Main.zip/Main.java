import animalmodels.Animal;
import foodmodels.Food;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Animal> animals = new ArrayList<>();
        List<Food> foods = new ArrayList<>();

        while (true) {
            String line = reader.readLine();
            if ("End".equals(line)) {
                break;
            }

            String[] tokens = line.split("\\s+");

            Animal animal = AnimalFactory.getAnimal(tokens[0], Arrays.stream(tokens).skip(1).toArray(String[]::new));
            tokens = reader.readLine().split("\\s+");
            Food food = FoodFactory.getFood(tokens[0], Integer.parseInt(tokens[1]));
            
            animals.add(animal);
            foods.add(food);
        }

        for (int i = 0; i < animals.size(); i++) {
            System.out.println(animals.get(i).makeSound());

            try {
                animals.get(i).eat(foods.get(i));
            } catch (IllegalArgumentException exception) {
                System.out.println(exception.getMessage());
            }

            System.out.println(animals.get(i).toString());
        }
    }
}
