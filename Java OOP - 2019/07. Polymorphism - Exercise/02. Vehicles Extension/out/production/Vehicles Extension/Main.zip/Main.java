import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        Car car = null;
        Truck truck = null;
        Bus bus = null;

        for (int i = 0; i < 3; i++) {
            String[] vehicleTokens = reader.readLine().split("\\s+");

            double fuelQuantity = Double.parseDouble(vehicleTokens[1]);
            double fuelConsumption = Double.parseDouble(vehicleTokens[2]);
            double tankCapacity = Double.parseDouble(vehicleTokens[3]);

            switch (vehicleTokens[0]) {
                case "Car":
                    car = new Car(fuelQuantity, fuelConsumption, tankCapacity);
                    break;
                case "Truck":
                    truck = new Truck(fuelQuantity, fuelConsumption, tankCapacity);
                    break;
                case "Bus":
                    bus = new Bus(fuelQuantity, fuelConsumption, tankCapacity);
                    break;
            }
        }

        int numberOfLines = Integer.parseInt(reader.readLine());

        for (int i = 0; i < numberOfLines; i++) {
            String[] tokens = reader.readLine().split("\\s+");

            String command = tokens[0];
            String vehicle = tokens[1];

            try {
                switch (command) {
                    case "Drive":
                        if (vehicle.equals("Car")) {
                            System.out.println(car.drive(Double.parseDouble(tokens[2])));
                        } else if(vehicle.equals("Truck")) {
                            System.out.println(truck.drive(Double.parseDouble(tokens[2])));
                        } else {
                            System.out.println(bus.drive(Double.parseDouble(tokens[2])));
                        }
                        break;
                    case "Refuel":
                        if (vehicle.equals("Car")) {
                            car.refuel(Double.parseDouble(tokens[2]));
                        } else if (vehicle.equals("Truck")) {
                            truck.refuel(Double.parseDouble(tokens[2]));
                        } else {
                            bus.refuel(Double.parseDouble(tokens[2]));
                        }
                        break;
                    case "DriveEmpty":
                        System.out.println(bus.driveEmpty(Double.parseDouble(tokens[2])));
                        break;
                }
            } catch (IllegalArgumentException exception) {
                System.out.println(exception.getMessage());
            }
        }
        System.out.println(car.toString());
        System.out.println(truck.toString());
        System.out.println(bus.toString());
    }
}
