package footballTeamGenerator;

public enum Skill {
    Endurance,
    Sprint,
    Dribble,
    Passing,
    Shooting,
}
