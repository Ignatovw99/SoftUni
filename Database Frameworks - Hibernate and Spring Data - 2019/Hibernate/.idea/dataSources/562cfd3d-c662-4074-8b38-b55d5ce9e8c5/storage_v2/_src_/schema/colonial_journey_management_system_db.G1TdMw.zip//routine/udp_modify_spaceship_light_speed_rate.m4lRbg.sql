create
  definer = root@localhost procedure udp_modify_spaceship_light_speed_rate(IN spaceship_name varchar(50), IN light_speed_rate_increase int)
BEGIN
	START TRANSACTION;
	IF (SELECT COUNT(`name`) FROM `spaceships` WHERE `name` = `spaceship_name`) <> 1 THEN
		SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Spaceship you are trying to modify does not exist.';
		ROLLBACK;
	ELSE
		UPDATE `spaceships`
        SET `light_speed_rate` = `light_speed_rate` + `light_speed_rate_increase`
        WHERE `name` = `spaceship_name`;
	END IF;
    COMMIT;
END;

